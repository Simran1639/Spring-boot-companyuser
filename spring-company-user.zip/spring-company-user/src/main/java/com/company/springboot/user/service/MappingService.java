package com.company.springboot.user.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.company.springboot.user.dto.UserLocationDto;
import com.company.springboot.user.entity.User;
import com.company.springboot.user.entityLocation.Location;
import com.company.springboot.user.repository.UserRepository;

@Service
public class MappingService {
	
	@Autowired
	public UserRepository userRepository;
	
	public List<UserLocationDto> getAllUsersLocation() {  
        return ((List<User>) userRepository  
                .findAll())  
                .stream()  
                .map(this::convertDataIntoDto)  
                        .collect(Collectors.toList());  
    }
	
	private UserLocationDto convertDataIntoDto(User userData) {
		
		UserLocationDto dto=new UserLocationDto();
		
		dto.setUserId(userData.getId());
		dto.setUsername(userData.getUsername());
		
		Location location = (Location) userData.getLocation();
		
		dto.setLatitude(location.getLatitude());
		dto.setLongitude(location.getLongitude());
		dto.setPlace(location.getPlaceName());
		

	
		return dto;
	
	}

}
