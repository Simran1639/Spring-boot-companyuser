package com.company.springboot.user.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import com.company.springboot.user.dto.UserLocationDto;
import com.company.springboot.user.service.MappingService;

@RestController
public class MappingController {
	
	@Autowired
	public MappingService mappingService;
	
	@GetMapping("/map")   
    @ResponseBody  
    public List<UserLocationDto> getAllUsersLocation() {  
        List <UserLocationDto> usersLocation = mappingService.getAllUsersLocation();   
        return usersLocation;  
	}
}
