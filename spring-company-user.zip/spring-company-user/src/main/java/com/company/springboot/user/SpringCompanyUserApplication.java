package com.company.springboot.user;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringCompanyUserApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringCompanyUserApplication.class, args);
	}

}
