package com.company.springboot.user;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringCompanyUserApplicationTests {

	@Test
	void contextLoads() {
	}

}
